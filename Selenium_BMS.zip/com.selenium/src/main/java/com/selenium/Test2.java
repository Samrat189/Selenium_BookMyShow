package com.selenium;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Test2{

	static WebDriver driver;
	static String url="https://www.flipkart.com";
	
	@BeforeClass
	public void setup() {
		System.setProperty("webdriver.gecko.driver", "/Users/samratroy/eclipse-workspace/com.selenium/DRIVER/geckodriver");
	
		driver = new FirefoxDriver();
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	
	@AfterClass
	public void close() {
		driver.quit();
	}
	
	
	@Test
	public void test1() throws InterruptedException {
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
		
		String title=driver.getTitle();
		if(title.contains("Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!")) {
			System.out.println("Page loaded and verified");
		}
		else {
			System.out.println("Page not verified");
		}
		
		Thread.sleep(3000);
		driver.findElement(By.name("q")).sendKeys("Home appliances");
		Thread.sleep(1000);
		driver.findElement(By.className("Y5N33s")).click();
		
		Thread.sleep(3000);
		driver.findElement(By.partialLinkText("SAMSUNG 6 kg 5 Star With Hygiene Steam and Ceramic Heat...")).click();
		Set<String> windowIds=driver.getWindowHandles();
		Iterator<String>itr=windowIds.iterator();
		String mainPageId=itr.next();
		String samsungId=itr.next();
		
		driver.switchTo().window(samsungId);
		
		Thread.sleep(4000);
		String product1=driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div[1]/h1/span")).getText();
		String amount1=driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div[3]/div[1]/div/div[1]")).getText();
		System.out.println(product1);
		
		System.out.println(amount1);
		
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[1]/div[2]/div/ul/li[1]/button")).click();
		Thread.sleep(3000);
		driver.close();
		Thread.sleep(3000);
		driver.switchTo().window(mainPageId);
		
		driver.findElement(By.partialLinkText("SAMSUNG 253 L Frost Free Double Door 3 Star Refrigerato...")).click();
		Set<String> handles2=driver.getWindowHandles();
		Iterator<String>itr2=handles2.iterator();
		String mainPage2Id=itr2.next();
		String handle2Id=itr2.next();
		
		driver.switchTo().window(handle2Id);
		
		String product2=driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div[1]/h1/span")).getText();
		String amount2=driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div[3]/div[1]/div/div[1]")).getText();
		System.out.println(product2);
		
		System.out.println(amount2);
		
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[1]/div[2]/div/ul/li[1]/button/text()")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[6]/div/div/a/span")).click();
		Thread.sleep(3000);
		String Totamt=driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[2]/div[1]/div/div/div/div[4]/div/div[2]/span/div/div/div[2]/span")).getText();
		
		System.out.println(Totamt);
		
		Thread.sleep(3000);
		
		
		
	}
	
	
}
