package com.selenium;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class SignIn {
	static WebDriver driver;
	static String url="https://in.bookmyshow.com/explore/home/mumbai";
	
	@BeforeClass
	public void setup() {
		System.setProperty("webdriver.gecko.driver", "/Users/samratroy/eclipse-workspace/com.selenium/DRIVER/geckodriver");
	
		driver = new FirefoxDriver();
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	
	
	@AfterClass
	public void close() {
		driver.quit();
		
	}
	
	@Test
	public void TestBookMyShow() throws InterruptedException {
		Thread.sleep(5000);
		//clicking signin
		driver.findElement(By.xpath("//div[text()='Sign in']")).click();
		Thread.sleep(5000);
		String mainWindow=driver.getWindowHandle();
		//clicking google
		driver.findElement(By.xpath("//*[@id=\"modal-root\"]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div/div")).click();
		Thread.sleep(5000);
		Set<String> set =driver.getWindowHandles();
		Iterator<String> itr= set.iterator();
		while(itr.hasNext()){
			String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				// for switching to the child window 
				driver.switchTo().window(childWindow);
				driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
				driver.findElement(By.xpath("//*[@id=\"identifierId\"]")).sendKeys("#123@gmail.com");
				Thread.sleep(5000);
				driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button/span")).click();
				driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
				String error=driver.findElement(By.xpath("//*[@id=\"view_container\"]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[1]/div/div[2]/div[2]/div")).getText();
				driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
			    System.out.println("Error is: "+error);
				
			}
		
		}
		
	}
}
