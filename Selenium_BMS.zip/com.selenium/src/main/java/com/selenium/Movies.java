package com.selenium;



import java.time.Duration;
import java.util.LinkedList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Movies {
	
	public List<String> languageList=new LinkedList<String>();
	WebDriver driver;
	@BeforeClass
	public void setUpDriver() {
		System.setProperty("webdriver.gecko.driver","/Users/samratroy/eclipse-workspace/com.selenium/DRIVER/geckodriver");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	@AfterClass
	public void closeBrowser() {
		driver.quit();
	}
	
	@Test(priority = 0)
	public void goToBookMyShowUrl() {
		driver.get("https://in.bookmyshow.com/");
	}
	
	@Test(priority = 1)
	public void selectCity() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[text()='Delhi-NCR']")).click();
		
		Thread.sleep(5000);
	
			
	}
	@Test(priority = 2)
	public void selectMoviesPage() throws InterruptedException {
		driver.findElement(By.xpath("//a[@class='sc-eKZiaR caGbXw' and text()='Movies']")).click();
		Thread.sleep(5000);
		
	}
	
	@Test(priority = 3)
	public void extractLanguage() {
		By name = By.xpath("//*[@id=\"super-container\"]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div");
		List<WebElement>languages=driver.findElements(name);
		
		for (WebElement webElement : languages) {
			languageList.add(webElement.getText());
		}
		
		for (String item : languageList) {
			System.out.println(item);	
		}
		
	}
}
