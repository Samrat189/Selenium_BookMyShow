package com.selenium;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Sports {

	WebDriver driver;
	public static HashMap<String, Integer> map = new HashMap<String, Integer>();
	public static int i;

	@BeforeClass
	public void setUpDriver() {
		// Create a instance of Webdriver

		System.setProperty("webdriver.gecko.driver",
				"/Users/samratroy/git/Selenium_BookMyShow/com.selenium/DRIVER/geckodriver");
		driver = new FirefoxDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@AfterClass
	public void closeBrowser() {
		driver.quit();
	}

	@Test(priority = 0)
	public void goToBookMyShowUrl() {
		driver.get("https://in.bookmyshow.com/");
	}

	@Test(priority = 1)
	public void selectCity() throws InterruptedException {

		driver.findElement(By.xpath("//*[text()='Delhi-NCR']")).click();

		Thread.sleep(5000);
		String actualTitile = "Movie Tickets, Plays, Sports, Events & Cinemas near Delhi-NCR - BookMyShow";
		assertEquals(driver.getTitle(), actualTitile);

	}

	@Test(priority = 2)
	public void selectSportsPage() throws InterruptedException {
		driver.findElement(By.xpath("//a[@class='sc-eKZiaR caGbXw' and text()='Sports']")).click();
		String actualTitile = "Top Upcoming Sports Events in Delhi-NCR | Live Sports Tournaments in Delhi-NCR - BookMyShow";
		Thread.sleep(5000);
		assertEquals(driver.getTitle(), actualTitile);
	}

	@Test(priority = 3)
	public void applyDateFilter() throws InterruptedException {
		driver.findElement(By.xpath("//div[@class='sc-7o7nez-0 eOgwQo' and text()='This Weekend']")).click();
		System.out.println("Weekend Selected");
		Thread.sleep(5000);

	}

	@Test(priority = 4)
	public void applyPriceFilter() throws InterruptedException {
		By priceSelection = By.xpath("(//div[normalize-space()='Price'])[1]");
		By zeroToFivehundred = By.xpath("(//div[contains(text(),'0 - 500')])[2]");

		driver.findElement(priceSelection).click();
		Thread.sleep(5000);
		driver.findElement(zeroToFivehundred).click();
		System.out.println("[0-500] Selected");
	}

	@Test(priority = 5)
	public void displayAllSports() throws InterruptedException {

		By Weekendfilter = By.xpath("//div[2][@class='sc-1ljcxl3-0 iUuHNJ']//a");
		By sportsname = By.xpath("(//div[2][@class='sc-1ljcxl3-0 iUuHNJ']//a)[" + (i + 1) + "]");
		By Title = By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/header/div/div/div[1]/div[1]/div[1]/h1");
		By Date = By.xpath("html/body/div[2]/div/div/div/div/div[2]/div/header/div/div/div[2]/div/div/div[1]/div/div");
		By Price = By.xpath(
				"/html/body/div[2]/div/div/div/div/div[2]/div/header/div/div/div[2]/div/div/div[2]/div[3]/div[1]");

		List<WebElement> weekendfilter = driver.findElements(Weekendfilter);

		if (weekendfilter.size() == 0) {
			System.out.println("No Sports this Weekend");
		} else {
			System.out.println("=========================================================================");
			System.out.println("Display sports activities. ");
			for (i = 0; i < weekendfilter.size(); i++) {
				JavascriptExecutor jse = (JavascriptExecutor) driver;
				jse.executeScript("arguments[0].scrollIntoView();", driver.findElement(sportsname));
				Thread.sleep(2000);
				jse.executeScript("arguments[0].click();",
						driver.findElement(By.xpath("(//div[2][@class='sc-1ljcxl3-0 iUuHNJ']//a)[" + (i + 1) + "]")));
				Thread.sleep(6000);
				String title = driver.findElement(Title).getText();
				String d = driver.findElement(Date).getText();
				String[] date = d.split("-");
				String p = driver.findElement(Price).getText();
				String[] price = p.split(" ");
				int priceint = Integer.parseInt(price[1]);
				System.out.println(title + " " + date[0]);
				System.out.println(priceint);
				map.put(title + " " + date[0], priceint);
				driver.navigate().back();
			}
			List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(map.entrySet());
			Collections.sort(list, new Comparator<Entry<String, Integer>>() {
				public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
					return o1.getValue().compareTo(o2.getValue());
				}
			});
			for (Entry<String, Integer> item : list) {
				System.out.println(item);
			}
			System.out.println("Sport activities are displayed Successfully");
			System.out.println("=========================================================================");
		}
	}
}
